from html import escape
import random

from aiogram import Router, F
from aiogram.types import (
    Message,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from aiogram.fsm.context import FSMContext
from aiogram.filters import Command, StateFilter

from states import StoryState
from config import ADMIN_IDS, CHANNEL_ID

from database import (
    create_story,
    update_ai_result,
    update_post,
    get_waiting_stories,
    get_all_stories,
    get_stats,
    get_open_dialog_by_user,
    create_support_dialog,
    add_support_message,
    get_open_dialogs,
    set_dialog_status,
    register_user,
    get_extended_stats,
    get_admin_control_message,
    get_admin_audit,
    get_reaction_stats,
    get_analytics,
    create_ai_priority,
    get_scheduled_stories,
    get_admin_role,
    get_admin_roles,
    set_admin_role,
    ensure_admin_roles,
)

from ai import analyze_story
from post_generator import create_post

from callbacks import refresh_dialog_card

from keyboards import (
    main_keyboard,
    admin_keyboard,
    admin_user_keyboard,
    moderation_keyboard,
    support_new_message_keyboard,
    personal_contact_keyboard,
    material_actions_keyboard,
    published_story_keyboard,
    admin_miniapp_keyboard,
)


router = Router()
MODERATOR_IDS = ADMIN_IDS.copy()


# =========================================================
# MATERIALS
# =========================================================

MATERIALS = {
    "anxiety": (
        "🧠 <b>Если тревога не отпускает</b>\n\n"
        "Тревога может ощущаться как постоянное напряжение "
        "или ощущение, что вот-вот произойдёт что-то плохое.\n\n"
        "Попробуйте остановиться на несколько минут и обратить "
        "внимание на дыхание.\n\n"
        "Сделайте несколько медленных вдохов и выдохов. "
        "Назовите про себя 5 вещей, которые видите, "
        "4 вещи, которых можете коснуться, "
        "3 звука, которые слышите."
    ),
    "stress": (
        "🌿 <b>Как немного снизить стресс</b>\n\n"
        "Попробуйте сделать небольшой перерыв, "
        "выйти на свежий воздух, выпить воды "
        "или убрать хотя бы одну небольшую задачу.\n\n"
        "Иногда пауза помогает двигаться дальше."
    ),
    "sleep": (
        "🌙 <b>Если трудно уснуть</b>\n\n"
        "Перед сном попробуйте уменьшить количество "
        "яркого света и отложить телефон.\n\n"
        "Можно сделать несколько спокойных вдохов и выдохов."
    ),
    "self_esteem": (
        "💙 <b>Когда кажется, что вы недостаточно хороши</b>\n\n"
        "Попробуйте вспомнить хотя бы три вещи, "
        "которые у вас сегодня получились.\n\n"
        "Ваша ценность не определяется одной ошибкой."
    ),
}


def materials_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="😟 Тревога",
                    callback_data="material:anxiety",
                ),
                InlineKeyboardButton(
                    text="😣 Стресс",
                    callback_data="material:stress",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🌙 Сон",
                    callback_data="material:sleep",
                ),
                InlineKeyboardButton(
                    text="💙 Самооценка",
                    callback_data="material:self_esteem",
                ),
            ],
        ],
    )


DAILY_TIPS = [
    "Не обязательно решать всю проблему сегодня. Иногда достаточно сделать один небольшой шаг.",
    "Если мысли постоянно возвращаются к одной проблеме, попробуйте записать их.",
    "Не требуйте от себя максимальной продуктивности каждый день.",
    "Если ситуация кажется огромной, разделите её на самое маленькое действие.",
    "Просить о помощи — нормально.",
]


def daily_tip_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🆘 Нужна поддержка",
                    callback_data="material:support",
                ),
            ],
        ],
    )


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def is_owner(user_id: int) -> bool:
    return is_admin(user_id) and user_id == ADMIN_IDS[0]


# =========================================================
# CHANNEL LINKS
# =========================================================

async def get_channel_message_link(
    bot,
    message_id: int,
):
    """
    Создаёт ссылку на конкретное сообщение канала.

    Для публичного канала:
        https://t.me/channel_username/message_id

    Для приватного канала:
        https://t.me/c/channel_id/message_id
    """

    try:
        chat = await bot.get_chat(
            chat_id=CHANNEL_ID
        )

        # Публичный канал
        if chat.username:
            return (
                f"https://t.me/"
                f"{chat.username}/"
                f"{message_id}"
            )

        # Приватный канал
        chat_id = str(chat.id)

        if chat_id.startswith("-100"):
            internal_id = chat_id[4:]

            return (
                f"https://t.me/c/"
                f"{internal_id}/"
                f"{message_id}"
            )

    except Exception as error:
        print(
            f"CHANNEL LINK ERROR: {error}"
        )

    return None


# =========================================================
# START
# =========================================================

@router.message(Command("start"))
async def start_command(
    message: Message,
    state: FSMContext,
):
    await state.clear()
    ensure_admin_roles(ADMIN_IDS)
    register_user(message.from_user.id)

    if is_admin(message.from_user.id):
        await message.answer(
            "👋 Добро пожаловать в «Проблем нет».\n\n"
            "👨‍💼 Вы вошли как администратор.\n\n"
            "Сейчас открыт режим пользователя.\n\n"
            "🆘 Если кому-то нужна помощь, "
            "можно воспользоваться функцией "
            "«Экстренная поддержка».",
            parse_mode="HTML",
            reply_markup=admin_user_keyboard,
        )
        return

    await message.answer(
        "👋 Добро пожаловать в «Проблем нет».\n\n"
        "Это пространство, где можно поделиться тем, "
        "что тревожит или беспокоит.\n\n"
        "💙 Здесь нет осуждения.\n\n"
        "📝 Нажмите «Поделиться историей».\n\n"
        "🆘 Если вам нужна помощь или просто хочется "
        "поговорить с сотрудником поддержки, "
        "воспользуйтесь функцией «Экстренная поддержка».\n\n"
        "📖 Также вы можете посмотреть истории "
        "других пользователей.\n\n"
        "Помните: проблем нет.",
        reply_markup=main_keyboard,
    )


# =========================================================
# HELP
# =========================================================

@router.message(Command("help"))
async def help_command(
    message: Message,
):
    await message.answer(
        "💡 <b>Как пользоваться ботом:</b>\n\n"
        "1️⃣ Нажмите «📝 Поделиться историей».\n"
        "2️⃣ Напишите свою историю.\n"
        "3️⃣ Бот подготовит материал.\n"
        "4️⃣ Администратор проверит его.\n\n"
        "🆘 Если нужна поддержка — используйте "
        "«Экстренная поддержка».\n\n"
        "📖 Опубликованные истории можно посмотреть "
        "через «Смотреть истории».",
        parse_mode="HTML",
    )


# =========================================================
# VIEW STORIES
# =========================================================

@router.message(F.text == "📖 Смотреть истории")
async def view_stories(
    message: Message,
):
    """
    Открывает самое первое сообщение канала.
    """

    link = await get_channel_message_link(
        message.bot,
        1,
    )

    if not link:
        await message.answer(
            "❌ Не удалось сформировать ссылку "
            "на канал.\n\n"
            "Проверь настройки CHANNEL_ID "
            "и права бота в канале."
        )
        return

    await message.answer(
        "📖 <b>Истории пользователей</b>\n\n"
        "Здесь собраны опубликованные истории.\n\n"
        "Нажмите кнопку ниже, чтобы открыть канал:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📖 Смотреть истории",
                        url=link,
                    ),
                ],
            ],
        ),
    )


# =========================================================
# ADMIN MODE
# =========================================================

@router.message(F.text == "🖥 Админ-панель")
async def open_admin_miniapp(
    message: Message,
    state: FSMContext,
):
    if not is_admin(message.from_user.id):
        return

    await state.clear()

    await message.answer(
        "🖥 <b>Панель модератора</b>\n\n"
        "Откройте Mini App для работы с историями, поддержкой, аналитикой и расписанием.",
        parse_mode="HTML",
        reply_markup=admin_miniapp_keyboard(),
    )


@router.message(F.text == "🖥 Открыть Mini App")
async def open_admin_miniapp_from_admin_mode(
    message: Message,
):
    if not is_admin(message.from_user.id):
        return

    await message.answer(
        "🖥 <b>Панель модератора</b>",
        parse_mode="HTML",
        reply_markup=admin_miniapp_keyboard(),
    )


@router.message(F.text == "🧰 Резервная админ-панель")
async def switch_to_admin_mode(
    message: Message,
    state: FSMContext,
):
    if not is_admin(message.from_user.id):
        return

    await state.clear()

    stats = get_extended_stats()

    await message.answer(
        "👨‍💼 <b>Резервная панель администратора</b>\n\n"
        f"⏳ На модерации: {stats['waiting']}\n"
        f"📚 Всего историй: {stats['total']}\n"
        f"✅ Опубликовано: {stats['published']}\n"
        f"❌ Отклонено: {stats['rejected']}\n\n"
        "Выберите действие:",
        parse_mode="HTML",
        reply_markup=admin_keyboard,
    )


# =========================================================
# USER MODE
# =========================================================

@router.message(F.text == "👤 Режим пользователя")
async def switch_to_user_mode(
    message: Message,
    state: FSMContext,
):
    if not is_admin(message.from_user.id):
        return

    await state.clear()

    await message.answer(
        "👤 <b>Режим пользователя</b>",
        parse_mode="HTML",
        reply_markup=admin_user_keyboard,
    )


# =========================================================
# DAILY TIP
# =========================================================

@router.message(F.text == "💡 Совет дня")
async def daily_tip(
    message: Message,
):
    await message.answer(
        "💡 <b>Совет дня</b>\n\n"
        + random.choice(DAILY_TIPS),
        parse_mode="HTML",
        reply_markup=daily_tip_keyboard(),
    )


# =========================================================
# MATERIALS
# =========================================================

@router.message(F.text == "📚 Полезные материалы")
async def useful_materials(
    message: Message,
):
    await message.answer(
        "📚 <b>Полезные материалы</b>\n\n"
        "Выберите тему:",
        parse_mode="HTML",
        reply_markup=materials_keyboard(),
    )


# =========================================================
# SUPPORT
# =========================================================

@router.message(F.text == "🆘 Экстренная поддержка")
async def emergency_support(
    message: Message,
    state: FSMContext,
):
    await state.clear()

    await state.set_state(
        StoryState.waiting_for_support_method
    )

    from keyboards import support_method_keyboard

    await message.answer(
        "🆘 <b>Экстренная поддержка</b>\n\n"
        "Если вам тяжело, вы можете рассказать "
        "о том, что происходит.\n\n"
        "Выберите способ общения:",
        parse_mode="HTML",
        reply_markup=support_method_keyboard(),
    )


# =========================================================
# SUPPORT MESSAGE
# =========================================================

@router.message(
    StoryState.waiting_for_support_message
)
async def receive_support_message(
    message: Message,
    state: FSMContext,
):
    if not message.text:
        await message.answer(
            "❗ Отправьте текстовое сообщение."
        )
        return

    text = message.text.strip()

    if len(text) < 2:
        await message.answer(
            "✏️ Напишите немного подробнее."
        )
        return

    user_id = message.from_user.id

    dialog = get_open_dialog_by_user(
        user_id
    )

    if dialog:
        dialog_id = dialog["id"]

        add_support_message(
            dialog_id,
            user_id,
            "user",
            text,
        )

        set_dialog_status(
            dialog_id,
            "in_progress",
        )

    else:
        dialog_id = create_support_dialog(
            user_id,
            text,
        )

    await notify_admins_about_message(
        message,
        dialog_id,
        text,
    )

    await state.clear()

    await message.answer(
        "💙 Сообщение передано сотруднику поддержки.\n\n"
        "Диалог остаётся открытым.",
        reply_markup=personal_contact_keyboard(),
    )


async def notify_admins_about_message(
    message: Message,
    dialog_id: int,
    text: str,
):
    dialog = get_open_dialog_by_user(message.from_user.id)
    assigned_admin = dialog["assigned_admin_id"] if dialog else None

    # Если диалог уже взят конкретным сотрудником,
    # обновляем его существующую карточку. Так кнопки всегда
    # находятся вместе с актуальным состоянием диалога.
    if assigned_admin:
        try:
            await refresh_dialog_card(message.bot, dialog_id)
            return
        except Exception as error:
            print(f"ACTIVE DIALOG REFRESH ERROR: {error}")

    admin_text = (
        "💬 <b>Новое сообщение в диалоге</b>\n\n"
        f"Диалог #{dialog_id}\n"
        f"👤 User ID: <code>{message.from_user.id}</code>\n\n"
        f"{escape(text)}"
    )

    for admin_id in MODERATOR_IDS:
        try:
            sent = await message.bot.send_message(
                admin_id,
                admin_text,
                reply_markup=support_new_message_keyboard(dialog_id),
                parse_mode="HTML",
            )
            # Запоминаем последнее управляющее сообщение.
            from database import set_admin_control_message
            set_admin_control_message(dialog_id, admin_id, sent.message_id)
        except Exception as error:
            print(f"DIALOG ADMIN ERROR ({admin_id}): {error}")


# =========================================================
# STORY CREATION
# =========================================================

@router.message(F.text == "📝 Поделиться историей")
async def start_story(
    message: Message,
    state: FSMContext,
):
    await state.clear()

    await state.set_state(
        StoryState.waiting_for_story
    )

    await message.answer(
        "💙 Расскажите свою историю.\n\n"
        "Можно написать всё, что вас беспокоит.\n\n"
        "🔒 История будет обработана анонимно."
    )


@router.message(
    StoryState.waiting_for_story
)
async def receive_story(
    message: Message,
    state: FSMContext,
):
    if not message.text:
        await message.answer(
            "❗ Отправьте историю обычным текстом."
        )
        return

    story = message.text.strip()

    if len(story) < 10:
        await message.answer(
            "✏️ История слишком короткая."
        )
        return

    story_id = create_story(
        message.from_user.id,
        story,
    )

    await message.answer(
        "🤖 Анализирую вашу историю..."
    )

    try:
        ai_result = await analyze_story(
            story
        )

    except Exception as error:
        print(
            f"AI ERROR: {error}"
        )

        ai_result = (
            "⚠️ Автоматический анализ временно "
            "недоступен. История сохранена. "
            "Администратор сможет обработать её вручную."
        )

    update_ai_result(
        story_id,
        ai_result,
    )

    danger_words = ("суицид", "самоуб", "покончи", "убить себя", "насили", "угроз")
    if any(word in ai_result.lower() for word in danger_words):
        create_ai_priority(story_id, "critical", "ИИ-анализ содержит потенциально опасные признаки")

    try:
        post_text = await create_post(
            story
        )

    except Exception as error:
        print(
            f"POST ERROR: {error}"
        )

        post_text = ""

    update_post(
        story_id,
        post_text,
    )

    moderation_text = (
        f"📥 <b>Новая история #{story_id}</b>\n\n"
        f"👤 User ID: "
        f"<code>{message.from_user.id}</code>\n\n"
        f"💭 <b>Текст:</b>\n\n"
        f"{escape(story)}\n\n"
        "━━━━━━━━━━━━━━\n\n"
        f"🤖 <b>Анализ ИИ:</b>\n\n"
        f"{escape(ai_result)}\n\n"
        "━━━━━━━━━━━━━━\n\n"
        f"📌 <b>Готовый пост:</b>\n\n"
        f"{escape(post_text) if post_text else '⚠️ Пост не сгенерирован. Используйте «✏️ Изменить».'}"
    )

    for admin_id in MODERATOR_IDS:
        try:
            await message.bot.send_message(
                admin_id,
                moderation_text,
                reply_markup=(
                    moderation_keyboard(
                        story_id,
                        message.from_user.id,
                    )
                ),
                parse_mode="HTML",
            )

        except Exception as error:
            print(
                f"ADMIN SEND ERROR: {error}"
            )

    await state.clear()

    await message.answer(
        "💙 Спасибо, что поделились.\n\n"
        "Ваша история отправлена на рассмотрение."
    )

    if is_admin(message.from_user.id):
        await message.answer(
            "👤 Вы остались в режиме пользователя.",
            reply_markup=admin_user_keyboard,
        )


# =========================================================
# ACTIVE USER SUPPORT
# =========================================================

@router.message(
    StateFilter(None),
    F.chat.type == "private",
    F.text,
    ~F.text.in_(
        {
            "📝 Поделиться историей",
            "💡 Совет дня",
            "📚 Полезные материалы",
            "🆘 Экстренная поддержка",
            "📖 Смотреть истории",
            "⬅️ Назад",
            "👨‍💼 Админ-панель",
            "👤 Режим пользователя",
            "⏳ Модерация",
            "📊 Статистика",
            "💬 Диалоги",
            "📁 Все истории",
            "📜 Журнал действий",
            "📈 Аналитика",
            "🗓 Запланированные",
            "💾 Резервная копия",
        }
    ),
)
async def active_support_message(
    message: Message,
    state: FSMContext,
):
    if is_admin(message.from_user.id):
        return

    dialog = get_open_dialog_by_user(
        message.from_user.id
    )

    if not dialog:
        return

    text = message.text.strip()

    if not text:
        return

    dialog_id = dialog["id"]

    add_support_message(
        dialog_id,
        message.from_user.id,
        "user",
        text,
    )

    set_dialog_status(
        dialog_id,
        "in_progress",
    )

    await notify_admins_about_message(
        message,
        dialog_id,
        text,
    )

    await message.answer(
        "💙 Сообщение передано сотруднику поддержки.",
        reply_markup=personal_contact_keyboard(),
    )

